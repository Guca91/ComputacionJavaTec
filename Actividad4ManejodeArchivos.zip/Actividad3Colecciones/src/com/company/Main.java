package com.company;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Main {

    private static Object HashMap;

    public static void main(String[] args)


    }

    public class AdressBook {
        HashMap<String, String> Dolby;

        public void load() throws IOException {
            String pathToCsv = "Actividad4.csv";
            BufferedReader csvReader = new BufferedReader(new FileReader(pathToCsv));
            while ((row = csvReader.readLine()) != null) {
                String[] data = row.split(",");
                Dolby.put(data[1], data[0]);
            }
            csvReader.close();

        }

        public void save(HashMap<String, String> nuevosContactos) throws IOException {
            HashMap<String, String> map = nuevosContactos;
            FileWriter csvWriter = new FileWriter("Actividad4.csv");
            for (Map.Entry<String, String> entry : map.entrySet()) {
                csvWriter.append(entry.getKey());
                csvWriter.append(",");
                csvWriter.append(entry.getValue());
                csvWriter.append("\n");
            }

            csvWriter.flush();
            csvWriter.close();
        }



            public void list(HashMap < String, String > contactos){

        }
            public void create(HashMap < String, String > contactos, Map.Entry<String, String> nuevoContacto){
                contactos.put(nuevoContacto.getKey(), nuevoContacto.getValue());

        }
            public void delete(HashMap < String, String > contactos, Map.Entry<String, String> contactoBorrar){
            contactos.remove(contactoBorrar.getKey());

        }


    }
    system.out.printIn(AdreesBook)
}